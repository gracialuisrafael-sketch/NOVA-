package mx.creativa.ia

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var projectName: EditText
    private lateinit var notes: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(17, 20, 30))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 8)
        }
        root.addView(label("CREATIVA IA", 28f))
        root.addView(label("Tu espacio creativo • prototipo inicial"))
        root.addView(label("Nombre del proyecto"))
        projectName = EditText(this).apply {
            hint = "Mi primer proyecto"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        root.addView(projectName, ViewGroup.LayoutParams(-1, -2))
        root.addView(label("Idea / instrucciones"))
        notes = EditText(this).apply {
            hint = "Describe lo que quieres crear..."
            minLines = 3
            gravity = Gravity.TOP
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        root.addView(notes, ViewGroup.LayoutParams(-1, -2))

        root.addView(label("Herramientas"))
        listOf(
            "Imagen — módulo pendiente",
            "Video — módulo pendiente",
            "Audio — módulo pendiente",
            "IA local / en línea — proveedor por configurar",
            "Reglas y módulos — base extensible"
        ).forEach { root.addView(label("• $it", 14f)) }

        val save = Button(this).apply {
            text = "Guardar proyecto en el teléfono"
            setOnClickListener { saveProject() }
        }
        root.addView(save, ViewGroup.LayoutParams(-1, -2))
        status = label("Los proyectos se guardan en el almacenamiento privado de la app.")
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun saveProject() {
        val name = projectName.text.toString().trim().ifBlank { "Proyecto" }
            .replace(Regex("[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ _-]"), "_")
        val file = java.io.File(filesDir, "$name.txt")
        file.writeText(
            "CREATIVA_IA_PROJECT_V1\n" +
            "name=$name\n\n" +
            notes.text.toString()
        )
        status.text = "Guardado localmente: ${file.name}"
    }
}
