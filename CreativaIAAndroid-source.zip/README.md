# Creativa IA Android — prototipo inicial

Este proyecto es un punto de partida Android compilable, no una IA generativa completa.
Incluye interfaz inicial, guardado de notas de proyecto en almacenamiento privado y un flujo
GitHub Actions que compila un APK de depuración.

## Compilar desde un teléfono
1. Sube todos los archivos de esta carpeta a un repositorio GitHub nuevo.
2. Abre la pestaña Actions del repositorio y habilita Actions si GitHub lo solicita.
3. Ejecuta `Build Android APK` con `Run workflow` (o sube el commit a la rama `main`).
4. Al terminar correctamente, abre la ejecución y descarga `CreativaIA-debug-apk` en Artifacts.
5. Extrae el ZIP descargado, abre `app-debug.apk` en Android y sigue las indicaciones del sistema.

## Limitaciones
Imagen, video, audio generativos, inferencia local, proveedores en línea, edición de medios y
actualización automática de código todavía no están implementados. Se deben añadir y probar
por módulos. No instales APKs de fuentes desconocidas. El APK de depuración no está firmado
para distribución pública.
